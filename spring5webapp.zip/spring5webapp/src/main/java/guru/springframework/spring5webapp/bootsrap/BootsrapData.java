package guru.springframework.spring5webapp.bootsrap;

import guru.springframework.spring5webapp.repositories.AgentsRepository;
import guru.springframework.spring5webapp.repositories.CustomersRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class BootsrapData implements CommandLineRunner {
    private final AgentsRepository agentsRepository;
    private final CustomersRepository customersRepository;

    @Override
    public void run(String... args) throws Exception {

    }
}
